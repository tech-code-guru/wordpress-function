<?php
/*Template: Custom filed
this template showing meta box in admin panel.
*/

add_action( 'add_meta_boxes', 'contacts_meta_box_add' );
function contacts_meta_box_add()
{
add_meta_box(
    'my-meta-box-id',
    'Custom Fields',
    'contacts_meta_box_form',
    'groups',         
    'normal',
    'low'      
  );
}

// view contacts meta field in admin panel
function contacts_meta_box_form()
{
    global $post;
	$phone = get_post_meta($post->ID, 'contacts_phone', true);
	$address = get_post_meta($post->ID, 'contacts_address', true);


    ?>
   <div class="form-group">
		<label for="Phone">Phone:</label>
		<input type="text" class="form-control" name="contacts_phone" id="contacts_phone" required value="<?php echo $phone; ?>"  placeholder="Enter your phone number..." style="width:100%;">
  </div>
	
  <div class="form-group">
		<label for="address">Address:</label>
		    <textarea class="form-control"  name="contacts_address" id="contacts_address"  required rows="8" style="width:100%;" placeholder="Enter your address..."><?php echo $address; ?></textarea>

  </div>
    <?php    
}

// add contacts meta data
add_action( 'save_post', 'contacts_meta_box_save' );
function contacts_meta_box_save( $post_id )
{
	echo 'jhgfhjf';
    if($_POST['contacts_phone'] =="" )
	{
				echo 'yes';

	}
	else
	{
		echo 'no';
	}
	
    if( isset( $_POST['contacts_phone'] ) )
        update_post_meta( $post_id, 'contacts_phone', $_POST['contacts_phone']);
	
	if( isset( $_POST['contacts_address'] ) )
        update_post_meta( $post_id, 'contacts_address', $_POST['contacts_address']);
         
}
?>
