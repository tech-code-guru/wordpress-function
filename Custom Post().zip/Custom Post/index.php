<?php
/*
Plugin Name: Custom Post(Plugin)
Description: This is a custom post plugin.
Author: संजय सिंह मनराल
Version: 8.8.8
Author URI: https://www.facebook.com/sanjay.manral.14
*/

add_action( 'init', 'custom_post_contacts' );

// custom post type function
function custom_post_contacts() {
 $labels = array(
  'name'               => _x( 'Contacts', 'post type general name', 'your-plugin-textdomain' ),
  'singular_name'      => _x( 'Contacts', 'post type singular name', 'your-plugin-textdomain' ),
  'menu_name'          => _x( 'Contacts', 'admin menu', 'your-plugin-textdomain' ),
  'name_admin_bar'     => _x( 'Contacts', 'add new on admin bar', 'your-plugin-textdomain' ),
  'add_new'            => _x( 'Add New', 'Contacts', 'your-plugin-textdomain' ),
  'add_new_item'       => __( 'Add New Contacts', 'your-plugin-textdomain' ),
  'new_item'           => __( 'New Contacts', 'your-plugin-textdomain' ),
  'edit_item'          => __( 'Edit Contacts', 'your-plugin-textdomain' ),
  'view_item'          => __( 'View Contacts', 'your-plugin-textdomain' ),
  'all_items'          => __( 'All Contacts', 'your-plugin-textdomain' ),
  'search_items'       => __( 'Search Contacts', 'your-plugin-textdomain' ),
  'parent_item_colon'  => __( 'Parent Contacts:', 'your-plugin-textdomain' ),
  'not_found'          => __( 'No Contacts found.', 'your-plugin-textdomain' ),
  'not_found_in_trash' => __( 'No Contacts found in Trash.', 'your-plugin-textdomain' )
 );

 $args = array(
  'labels'             => $labels,
  'description'        => __( 'Description.', 'your-plugin-textdomain' ),
  'public'             => true,
  'publicly_queryable' => true,
  'show_ui'            => true,
  'show_in_menu'       => true,
  'query_var'          => true,
  'rewrite'            => array( 'slug' => 'groups' ),
  'capability_type'    => 'post',
  'has_archive'        => true,
  'hierarchical'       => false,
  'menu_position'      => null,
  'supports'           => array( 'title')
 );

 register_post_type( 'groups', $args );
 
}



// custom post type taxonomy
function contacts_taxonomy() {

 $labels = array(
  'name'                       => _x( 'Groups', 'Taxonomy General Name', 'your-plugin-textdomain' ),
  'singular_name'              => _x( 'Groups', 'Groups Singular Name', 'your-plugin-textdomain' ),
  'menu_name'                  => __( 'Groups', 'your-plugin-textdomain' ),
  'all_items'                  => __( 'All Items', 'your-plugin-textdomain' ),
  'parent_item'                => __( 'Parent Item', 'your-plugin-textdomain' ),
  'parent_item_colon'          => __( 'Parent Item:', 'your-plugin-textdomain' ),
  'new_item_name'              => __( 'New Item Name', 'your-plugin-textdomain' ),
  'add_new_item'               => __( 'Add New Item', 'your-plugin-textdomainl' ),
  'edit_item'                  => __( 'Edit Item', 'your-plugin-textdomain' ),
  'update_item'                => __( 'Update Item', 'your-plugin-textdomain' ),
  'separate_items_with_commas' => __( 'Separate items with commas', 'your-plugin-textdomain' ),
  'search_items'               => __( 'Search Items', 'your-plugin-textdomain' ),
  'add_or_remove_items'        => __( 'Add or remove items', 'your-plugin-textdomain' ),
  'choose_from_most_used'      => __( 'Choose from the most used items', 'your-plugin-textdomain' ),
  'not_found'                  => __( 'Not Found', 'your-plugin-textdomain' ),
 );
 $args = array(
  'labels'                     => $labels,
  'hierarchical'               => true,
  'public'                     => true,
  'show_ui'                    => true,
  'show_admin_column'          => true,
  'show_in_nav_menus'          => true,
  'show_tagcloud'              => true,
 );
 register_taxonomy( 'contacts', array( 'groups' ), $args );

}

add_action( 'init', 'contacts_taxonomy', 0 );


//include custom field template
include(plugin_dir_path( __FILE__ ) .  '/inc/custom_fileds.php');



?>
